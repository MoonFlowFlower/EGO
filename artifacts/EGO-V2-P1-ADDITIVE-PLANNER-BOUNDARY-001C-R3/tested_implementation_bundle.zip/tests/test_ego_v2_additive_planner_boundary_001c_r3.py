from __future__ import annotations

from copy import deepcopy

import numpy as np

from labs.ego_life_playground_v0 import engine, predictive_control
from labs.ego_life_playground_v0.microworld import PUBLIC_OBSERVATION_SCHEMA_VERSION


def _observation(front: str = "v3") -> dict:
    visual = [["occluded" for _ in range(5)] for _ in range(5)]
    visual[2][2] = "self"
    visual[1][2] = front
    visual[2][1] = "empty"
    visual[2][3] = "empty"
    visual[3][2] = "empty"
    return {"schema_version": PUBLIC_OBSERVATION_SCHEMA_VERSION, "visual": visual}


def _organism() -> dict[str, float]:
    return {
        "energy": 0.45,
        "safety": 0.62,
        "connection": 0.50,
        "stimulation": 0.43,
    }


def _prepared() -> tuple[dict, dict]:
    observation = _observation()
    state, _ = predictive_control.observe_belief(
        predictive_control.empty_state(),
        observation=observation,
        episode_index=0,
        mode="relative",
    )
    return state, observation


def test_batched_additive_vectors_are_bit_exact_to_scalar_for_clipped_rows() -> None:
    state, observation = _prepared()
    compiled = predictive_control._compiled_model_arrays(state["model"])  # noqa: SLF001
    payload = predictive_control.predictor_input_snapshot(
        state,
        observation=observation,
        organism=_organism(),
        relative_map_mode="relative",
    )
    offsets = np.asarray(compiled["delta_outcome_offsets"][0]).copy()
    offsets[0] = np.asarray([0.40, -0.40, 0.02, -0.02])
    offsets[1] = -offsets[0]
    packed_rows = np.asarray(
        [
            [0.1, -0.2, 0.3, -0.4, 0.2, 0.0, 0.10, -0.10, 0.20, -0.20, 0.4, -0.3],
            [-0.3, 0.2, 0.1, 0.0, -0.1, 0.4, -0.20, 0.20, -0.10, 0.10, -0.2, 0.5],
        ],
        dtype=predictive_control.NUMERIC_DTYPE,
    )
    visit_counts = [0, 7]
    scalar = [
        predictive_control._planning_prediction_vector_from_packed(  # noqa: SLF001
            state,
            payload=payload,
            action="turn_left",
            packed_values=row,
            delta_outcome_offsets=offsets,
            visit_key_cache={},
        )[:-1]
        + (1.0 / np.sqrt(1.0 + visit_counts[index]),)
        for index, row in enumerate(packed_rows)
    ]

    batched = predictive_control._batch_planning_prediction_vectors(  # noqa: SLF001
        packed_rows,
        delta_outcome_offsets=offsets,
        visit_counts=visit_counts,
    )

    assert batched == scalar


def test_depth_prewarm_plan_is_exact_to_lazy_scalar_ablation(monkeypatch) -> None:
    state, observation = _prepared()
    kwargs = {
        "state": state,
        "observation": observation,
        "organism": _organism(),
        "active_goal": "energy",
        "heuristic_scores": {action: 0.0 for action in engine.ACTIONS},
        "horizon": predictive_control.HORIZON,
        "beam_width": predictive_control.BEAM_WIDTH,
        "discount": predictive_control.DISCOUNT,
        "relative_map_mode": "relative",
        "goal_value_mode": "contextual",
        "action_costs": engine.ACTION_COSTS,
        "run_seed": 711,
        "episode_index": 0,
        "sequence": 1,
    }
    batched = predictive_control.plan_action(**kwargs)
    monkeypatch.setattr(
        predictive_control,
        "_prewarm_depth_prediction_caches",
        lambda *args, **kwargs: {"request_count": 0, "unique_miss_count": 0},
    )
    scalar = predictive_control.plan_action(**kwargs)

    assert batched["batch_receipt"]["unique_miss_count"] > 0
    batched = {key: value for key, value in batched.items() if key != "batch_receipt"}
    scalar = {key: value for key, value in scalar.items() if key != "batch_receipt"}
    assert batched == scalar


def test_compact_projection_receipt_retains_evidence_without_full_state_dict() -> None:
    state, observation = _prepared()
    updated, report = predictive_control.update_after_transition(
        state,
        observation=observation,
        organism_before=_organism(),
        action="interact",
        actual_outcome_type="interacted",
        actual_delta={
            "energy": 0.262,
            "safety": 0.0,
            "connection": 0.0,
            "stimulation": 0.0,
        },
        terminal=False,
        resource_interaction=True,
        next_observation=observation,
        episode_index=0,
        relative_map_mode="relative",
        updates_enabled=True,
    )
    del updated

    compact = engine._compact_predictive_update(deepcopy(report))  # noqa: SLF001

    assert "delta_projection_by_state" not in compact
    projection = compact["delta_projection"]
    assert set(projection["projection_mean_by_state"]) == set(engine.STATE_KEYS)
    assert projection["raw_conditionals_hash"]
    assert projection["projected_conditionals_hash"]
    assert projection["projection_max_abs_difference"] <= 1e-11
    assert projection["all_projection_conditionals_preserved"] is True
